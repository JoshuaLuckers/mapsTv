--------------------
Extra: MapsTv
--------------------
Version: 1.1.0
Author: Sterc <modx+mapstv@sterc.nl>
License: GNU GPLv2
Github: https://github.com/sterc/mapstv/

MapsTv is a custom TV. It will show a Google Maps map (API v3) in your resource template variables with some fields to specify the address. 
The Latitude and Longitude will be generated automatically.

If the marker not on the accurate position on the map you can drag the marker to the right destination, only the latitude and longitude will be updated.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/sterc/mapstv/issues

Installation:
Install in MODX package management.